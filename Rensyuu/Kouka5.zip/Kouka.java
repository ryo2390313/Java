package Rensyuu;
import java.util.Scanner;
public class Kouka {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] scores = new int[5];

        for (int i = 0; i < 5; i++) {
            System.out .print("教科" + (i + 1));
        }
    }
}
