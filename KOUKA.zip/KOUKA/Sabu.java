package KOUKA;

public class Sabu extends View{
    private Itkigyou[] companies;

    public Sabu(Itkigyou[] companies) {
        this.companies = companies;
    }

    public Itkigyou[] getCompanies() {
        return companies;
    }
    
    public void displayAllCompanies() {
        displayOverview(this);
    }
}
